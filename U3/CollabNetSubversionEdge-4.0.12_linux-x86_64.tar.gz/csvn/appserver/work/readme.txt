This folder act as a temp folder for the appserver to expand the running webapps
on the server.  It is OK to clear the contents of this folder when the server
is not running to force it to redeploy the webapp from the WAR file.